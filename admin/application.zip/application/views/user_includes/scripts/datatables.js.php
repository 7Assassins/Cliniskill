<script src="<?php echo base_url();?>user_assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="<?php echo base_url();?>user_assets/js/dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>