<footer>
    <center><p>Designed and developed by: <a target="_blank" href="https://www.svapps.in/">SVAPPS Soft Solutions Pvt Ltd</a></p></center>

				</footer>