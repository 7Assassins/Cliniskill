<ul id="dropdown1" class="dropdown-content">
<li><a href="<?php echo site_url('user/change-password');?>"><i class="fa fa-gear fa-fw"></i> Change Password</a>
</li> 
<li><a href="<?php echo base_url('user/logout');?>"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
</li>
</ul>