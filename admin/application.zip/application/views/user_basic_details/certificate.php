<!DOCTYPE html>
<html lang="en">

<head>
    <title>Certificate</title>
    <link rel="stylesheet" href="<?php echo base_url();?>certificate_assets/style.css">
</head>
<style>
    @media print {
  #printPageButton {
    display: none;
  }
}
</style>

<body>
<?php 
    $certificateDetails = $this->db->select('*')->from('certificate_details')->where('cd_id',$this->uri->segment(3))->get()->result();
    $grades = explode('.#$-',$certificateDetails[0]->cd_grades);
    
?>
<center><button id="printPageButton" onClick="window.print();">Print</button></center>
    <div class="certificate">
        <!-- <img src="assets/im" alt=""> -->
        <div class="content">
            <h3><?php echo $certificateDetails[0]->cd_name_of_the_certificate;?></h3>
            <br>
            <span><strong>*Candidate Name :</strong> <?php echo $details['cr_name'];?></span>

            <p><?php echo $certificateDetails[0]->cd_description;?></p>

            <table class="table ">
                <tr>
                    <td><strong> Registration Number</strong> :</td>
                    <td><?php echo $details['cr_reg_number'];?></td>
                </tr>
                
                <tr>
                    <td><strong>Date of Completion </strong> :</td>
                    <td><?php echo $details['cr_date_of_completion'];?></td>
                </tr>
                
                <tr>
                    <td><strong>Location</strong> :</td>
                    <td><?php echo $details['cr_location'];?></td>
                </tr>
                
                <tr>
                    <td><strong>Grades</strong> :</td>
                    <td><?php echo $details['grades'];?></td>
                </tr>
            </table>
            
            <!--<p><strong>Registration Number:</strong> <?php echo $details['cr_reg_number'];?></p>-->
            <!--<p><strong>Location:</strong>: <?php echo $details['cr_location'];?></p>-->
            <!--<p><strong>Date of Completion: <?php echo $details['cr_date_of_completion'];?></strong></p>-->
            <!--<p><strong>Grades:<?php echo $details['grades'];?></strong></p>-->
            <br>
            <?php 
                for($i=0;$i<count($grades);$i++){
            ?>
            <p><?php echo $grades[$i];?></p>
            <?php } ?>
            

            <div class="date-signature">
                <p>Date</p>
                <p>Signature of Training Manager</p>
            </div>
        </div>
    </div>
</body>

</html>